package com.example.demo.entity.user;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import com.example.demo.entity.Subject;

@Entity
@Table(name = "STANDARD")
public class Standard {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@NotBlank
	private byte classNumber;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "standards")
	private Set<Subject> subjects;

	@NotBlank
	private String section;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public byte getClassNumber() {
		return classNumber;
	}

	public void setClassNumber(byte classNumber) {
		this.classNumber = classNumber;
	}

	public Set<Subject> getSubjects() {
		if (this.subjects == null) {
			this.subjects = new HashSet<>();
		}
		return subjects;
	}

	public void setSubjects(Set<Subject> subjects) {
		this.subjects = subjects;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

}

package com.example.demo.payload.request;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class TeacherSignupRequestPayload {

	private SignupRequestPayload signupPayload;
	private CommonSignupRequestPayload commonDetailsPayload;

	public SignupRequestPayload getSignupPayload() {
		return signupPayload;
	}

	public void setSignupPayload(SignupRequestPayload signupPayload) {
		this.signupPayload = signupPayload;
	}

	public CommonSignupRequestPayload getCommonDetailsPayload() {
		return commonDetailsPayload;
	}

	public void setCommonDetailsPayload(CommonSignupRequestPayload commonDetailsPayload) {
		this.commonDetailsPayload = commonDetailsPayload;
	}

	@Override
	public String toString() {
		return "TeacherSignupRequestPayload [signupPayload=" + signupPayload + ", commonDetailsPayload="
				+ commonDetailsPayload + "]";
	}

	
}

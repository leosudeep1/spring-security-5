package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.example.demo.entity.user.Standard;

@Entity
@Table(name = "TAB_SUBJECT")
public class Subject {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@NotNull
	private String subjectName;

	@ManyToOne()
	@JoinTable(name = "STANDARD_SUBJECT", 
		joinColumns = @JoinColumn(name = "subject_id"), 
		inverseJoinColumns = @JoinColumn(name = "class_id"))
	private Standard standards;

	@NotNull
	private String section;

	@NotNull
	@ManyToOne
	@JoinTable(name = "STANDARD_TEACHER",
	joinColumns = @JoinColumn(name = "subject_id"),
	inverseJoinColumns = @JoinColumn(name = "teacher_id"))
	private Teacher teacher;

	@NotNull
	private String edition;

	@NotNull
	private String authorName;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public Standard getStandards() {
		return standards;
	}

	public void setStandards(Standard standards) {
		this.standards = standards;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	public String getEdition() {
		return edition;
	}

	public void setEdition(String edition) {
		this.edition = edition;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
}

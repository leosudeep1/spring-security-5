package com.example.demo.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.example.demo.entity.user.Standard;

@Entity
@Table(name = "TAB_TEACHER")
public class Teacher {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "APPUSER_ID")
	AppUser credentials;

	@Embedded
	private CommonDetails commanDetails = new CommonDetails();

	@OneToMany(mappedBy = "teacher")
	private Set<Subject> teachesInClasses;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public AppUser getCredentials() {
		return credentials;
	}

	public void setCredentials(AppUser credentials) {
		this.credentials = credentials;
	}

	public CommonDetails getCommanDetails() {
		return commanDetails;
	}

	public void setCommanDetails(CommonDetails commanDetails) {
		this.commanDetails = commanDetails;
	}

	public Set<Subject> getTeachesInClasses() {
		
		if (this.teachesInClasses == null) {
			this.teachesInClasses = new HashSet<Subject>();
		}
		return teachesInClasses;
	}

	public void setTeachesInClasses(Set<Subject> teachesInClasses) {
		this.teachesInClasses = teachesInClasses;
	}

}

package com.example.demo.enums;

public enum RoleName {

	ROLE_USER,
    ROLE_ADMIN,
    ROLE_ANONYMOUS,
    ROLE_SUPER_ADMIN,
    ROLE_TEACHER,
    ROLE_STUDENT,
    ROLE_PARENTS
}

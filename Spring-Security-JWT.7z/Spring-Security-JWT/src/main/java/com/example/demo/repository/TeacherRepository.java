package com.example.demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Teacher;

@Repository
public interface TeacherRepository extends JpaRepository<Teacher, Long> {
    Optional<Teacher> findByCredentialsEmail(String email);

    List<Teacher> findByIdIn(List<Long> userIds);

    Optional<Teacher> findByCredentialsUsername(String username);

    Boolean existsByCredentialsUsername(String username);

    Boolean existsByCredentialsEmail(String email);
    
}

import { NgModule } from '@angular/core';
import {
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatRadioModule,
    MatNativeDateModule,
    MatGridListModule, 
    MatMenuModule,
    MatTableModule,
    MatTabsModule,
    MatSnackBarModule
    } from '@angular/material';

@NgModule({
    imports: [
        MatToolbarModule,
        MatButtonModule,
        MatSidenavModule,
        MatIconModule,
        MatListModule,
        MatCardModule,
        MatFormFieldModule,
        MatInputModule,
        MatCheckboxModule,
        MatDatepickerModule,
        MatRadioModule,
        MatNativeDateModule,
        MatGridListModule, 
        MatMenuModule,
        MatTableModule,
        MatTabsModule,
        MatSnackBarModule
    ],
    exports: [
        MatToolbarModule,
        MatButtonModule,
        MatSidenavModule,
        MatIconModule,
        MatListModule,
        MatCardModule,
        MatFormFieldModule,
        MatInputModule,
        MatCheckboxModule,
        MatDatepickerModule,
        MatRadioModule,
        MatNativeDateModule,
        MatGridListModule, 
        MatMenuModule,
        MatTableModule,
        MatTabsModule,
        MatSnackBarModule
    ]
})
export class MaterialModule { }
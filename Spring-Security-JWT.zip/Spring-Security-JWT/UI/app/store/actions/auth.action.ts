import { Action } from "@ngrx/store";

export const SET_AUTHENTICATED = '[AUTH] Set Authenticated';
export const SET_UN_AUTHENTICATED = '[AUTH] Set UnAuthenticated';

export class SetAuthenticated implements Action {
    readonly type = SET_AUTHENTICATED;
}

export class SetUnAuthenticated implements Action {
    readonly type = SET_UN_AUTHENTICATED;
}

export type AuthActions = SetAuthenticated | SetUnAuthenticated;
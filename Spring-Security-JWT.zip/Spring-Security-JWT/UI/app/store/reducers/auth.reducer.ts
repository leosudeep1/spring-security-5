import { AuthActions, SET_AUTHENTICATED, SET_UN_AUTHENTICATED } from './../actions/auth.action';

export interface State {
    isAuthencated: boolean;
}

export const initialState: State = {
    isAuthencated: false
}

export function authReducer(state = initialState, action : AuthActions) {
    switch(action.type) {
        case SET_AUTHENTICATED:
            return {
                isAuthencated: true
            };
        case SET_UN_AUTHENTICATED:
            return {
                isAuthencated: false
            };
        default:
            return state;
    }
}

export const getAuth = (state: State) => state.isAuthencated;
import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-signup-form',
  templateUrl: './signup-form.component.html',
  styleUrls: ['./signup-form.component.css']
})
export class SignupFormComponent implements OnInit {
  startDate = new Date(1990, 0, 1);
  signupForm: FormGroup;
  constructor(private fb : FormBuilder) { }

  ngOnInit() {
    this.signupForm = this.fb.group({
      name: ['',Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['',Validators.required],
      dob:['',Validators.required],
    })
  }

  getEmailErrorMessage() {
    return this.email.hasError('required') ? 'You must enter email' :
      this.email.hasError('email') ? 'Not a valid email' :
        '';
  }

  getNameErrorMessage() {
    return this.name.hasError('required') ? 'You must enter your full name' :'';
  }

  getPasswordErrorMessage() {
    return this.password.hasError('required') ? 'You must enter your password' :'';
  }

  getDobErrorMessage() {
    return this.dob.hasError('required') ? 'You must select your date of birth' :'';
  }
  get name() {
    return this.signupForm.get('name'); 
  }

  get email() {
    return this.signupForm.get('email'); 
  }
  get password() {
    return this.signupForm.get('password'); 
  }
  get dob() {
    return this.signupForm.get('dob'); 
  }


}

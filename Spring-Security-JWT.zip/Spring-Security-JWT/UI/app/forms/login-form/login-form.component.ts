import { Router } from '@angular/router';
import { AuthService } from './../../service/auth/auth.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Store } from '@ngrx/store';
import {MatSnackBar} from '@angular/material';

import * as fromRoot from './../../app.reducer';
import * as AUTH from './../../store/actions/auth.action';
@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css']
})
export class LoginFormComponent implements OnInit {
  loginForm : FormGroup;
  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private store: Store<fromRoot.State>,
    private router: Router,
    private snackBar: MatSnackBar
  ) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['',Validators.required],
    })
  }

  getEmailErrorMessage() {
    return this.email.hasError('required') ? 'You must enter email' :
      this.email.hasError('email') ? 'Not a valid email' :
        '';
  }

  getPasswordErrorMessage() {
    return this.password.hasError('required') ? 'You must enter your password' :'';
  }

  get email() {
    return this.loginForm.get('email'); 
  }
  get password() {
    return this.loginForm.get('password'); 
  }

  login() {
    console.log('calling login service');
    let isValid = this.authService.obtainAccessToken(this.loginForm.value);
    if(isValid) {
      // here we change the value of isAuthenticated on global store
      this.store.dispatch(new AUTH.SetAuthenticated());
      this.router.navigate(['/home']);
    } else {
      this.snackBar.open("Invalid Credential", 'close',{
        duration: 2000,
        panelClass: ['danger-snackbar']
      });
    }
  }

  logout() {
    this.store.dispatch({ type: 'UN_AUTHENTICATED'});
  }
  
}

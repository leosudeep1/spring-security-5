import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { HttpModule, Http, RequestOptions, Headers } from '@angular/http';
import { Injectable } from "@angular/core";
import { Router } from '@angular/router';
import { OAuthService } from 'angular-oauth2-oidc';
import { JwksValidationHandler } from 'angular-oauth2-oidc';

@Injectable()
export class AuthService {
    private flag: boolean = false;
    // constructor(
    //     private _router: Router, private _http: Http, private oauthService: OAuthService
    // ) {
    //     this.oauthService.loginUrl = 'http://localhost:8081/spring-security-oauth-server/oauth/authorize';
    //     this.oauthService.redirectUri = window.location.origin;
    //     this.oauthService.clientId = "sampleClientId";
    //     this.oauthService.scope = "read write foo bar";
    //     this.oauthService.setStorage(sessionStorage);
    //     this.oauthService.tryLogin({});
    // }

    private url = 'http://localhost:8080/oauth/token';
    constructor(
        private _router: Router, private _http: Http) { }

    private _flag: boolean = false;
    obtainAccessToken(loginData): boolean {
        let params = new URLSearchParams();
        params.append('username', loginData.email);
        params.append('password', loginData.password);
        params.append('grant_type', 'password');
        params.append('scopes', 'read write');

        let headers = new Headers({ 
            'Content-type': 'application/x-www-form-urlencoded; charset=utf-8', 
            'Authorization': 'Basic ' + btoa("myapp:1234")});
        let options = new RequestOptions({ headers: headers });
        console.log(params.toString());
        this._http.post(this.url, params.toString(), options)
            .pipe(map(res => res.json()))
            .subscribe(
                data => { 
                    this.saveToken(data); 
                    this._flag = true
                    console.info('token' + data.json); 
                },
                err => this._flag = false
            );
        return this._flag;
    }


    saveToken(token) {
        sessionStorage.setItem("access_token", token.access_token);
        console.log('Obtained Access token');
        this._router.navigate(['/']);
    }

    //   getResource(resourceUrl) : Observable<Foo>{
    //     var headers = new Headers({'Content-type': 'application/x-www-form-urlencoded; charset=utf-8', 'Authorization': 'Bearer '+sessionStorage.getItem('access_token')});
    //     var options = new RequestOptions({ headers: headers });
    //     return this._http.get(resourceUrl, options)
    //                    .map((res:Response) => res.json())
    //                    .catch((error:any) => Observable.throw(error.json().error || 'Server error'));
    //   }

    checkCredentials() {
        if (!sessionStorage.getItem('access_token')) {
            this._router.navigate(['/login']);
        }
    }

    logout() {
        sessionStorage.removeItem('access_token');
        this._router.navigate(['/login']);
    }
}
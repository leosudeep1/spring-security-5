//import { map } from 'rxjs/add/operators';
import { map } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { Component, OnInit } from '@angular/core';

import * as fromRoot from './app.reducer';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'app';
  isLoggedIn$: Observable<boolean>;

  constructor(private store: Store<fromRoot.State>) {}

  ngOnInit() {
    this.isLoggedIn$ = this.store.select(fromRoot.getIsAuthenticated);
    console.log('AppComponent :: isLoggedIn$ value :'+this.isLoggedIn$);
  }
}

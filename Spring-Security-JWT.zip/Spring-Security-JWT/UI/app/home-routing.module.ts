import { DashboardComponent } from './dashboard/dashboard.component';
import { AttendanceComponent } from './data-table/attendance/attendance.component';

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { MainNavComponent } from './main-nav/main-nav.component';
import { AuthGuard } from './guards/auth.guard';

const homeModuleRoutes: Routes = [
    {
        path: 'home',            //<---- parent component declared here
        component: MainNavComponent,
        children: [
            { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
            { path: 'attendance', component: AttendanceComponent},
        ]
    }
];

@NgModule({
    imports: [
        RouterModule.forChild(homeModuleRoutes)
    ],
    declarations: [],
    exports: [
        RouterModule
    ]
})
export class AppRoutingModule { }
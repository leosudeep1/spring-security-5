import { DashboardComponent } from './dashboard/dashboard.component';
import { AttendanceComponent } from './data-table/attendance/attendance.component';
import { AnonymousGuard } from './guards/anonymous.guard';
import { SignupFormComponent } from './forms/signup-form/signup-form.component';
import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginFormComponent } from './forms/login-form/login-form.component';
import { MainNavComponent } from './main-nav/main-nav.component';
import { AuthGuard } from './guards/auth.guard';

const routes: Routes = [
    { path: '',  redirectTo: '/home',  pathMatch: 'full'},
    { 
        path: 'home', 
        component: MainNavComponent, 
        canActivate: [AuthGuard],
        children: [
            { path: 'dashboard', component: DashboardComponent },
            { path: 'attendance', component: AttendanceComponent},
        ]
    },
    { path: 'login', component: LoginFormComponent },
    { path: 'signup', component: SignupFormComponent,canActivate: [AnonymousGuard] },
];

@NgModule({
    imports: [
        RouterModule.forRoot(routes)
    ],
    exports: [RouterModule],
    providers: [AuthGuard, AnonymousGuard]
})
export class AppRoutingModule { }
import { AuthService } from './service/auth/auth.service';

import { AppRoutingModule } from './app-routing.module';
import { reducers } from './app.reducer';
import { MaterialModule } from './material.module';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { LayoutModule } from '@angular/cdk/layout';
import { HttpModule } from '@angular/http';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';

import { AppComponent } from './app.component';
import { MainNavComponent } from './main-nav/main-nav.component';

import { HeaderComponent } from './navigation/header/header.component';
import { SidenavListComponent } from './navigation/sidenav-list/sidenav-list.component';
import { SignupFormComponent } from './forms/signup-form/signup-form.component';
import { LoginFormComponent } from './forms/login-form/login-form.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AttendanceComponent } from './data-table/attendance/attendance.component';

@NgModule({
  declarations: [
    AppComponent,
    MainNavComponent,
    HeaderComponent,
    SidenavListComponent,
    SignupFormComponent,
    LoginFormComponent,
    DashboardComponent,
    AttendanceComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    LayoutModule,
    MaterialModule,
    AppRoutingModule ,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    HttpModule,
    StoreModule.forRoot(reducers),
    StoreDevtoolsModule.instrument({
      maxAge:10
    })  
  ],
  providers: [AuthService],
  bootstrap: [AppComponent]
})
export class AppModule { }

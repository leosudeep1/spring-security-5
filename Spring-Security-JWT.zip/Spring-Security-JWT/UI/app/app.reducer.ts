import { ActionReducerMap, createFeatureSelector, createSelector } from '@ngrx/store';

import * as fromUI from "./store/reducers/ui.reducer";
import * as fromAUTH from "./store/reducers/auth.reducer";

export interface State {
    ui: fromUI.State;
    auth: fromAUTH.State;
}

export const reducers: ActionReducerMap<State> = {
    ui: fromUI.uiReducer,
    auth: fromAUTH.authReducer
}
export const getUiState = createFeatureSelector<fromUI.State>('ui');
export const getAuthState = createFeatureSelector<fromAUTH.State>('auth');

export const getIsLoading = createSelector(getUiState, fromUI.getLoading);
export const getIsAuthenticated = createSelector(getAuthState, fromAUTH.getAuth);
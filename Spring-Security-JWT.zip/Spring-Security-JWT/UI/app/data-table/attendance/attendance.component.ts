
import { Observable } from 'rxjs';
import { Component, OnInit } from '@angular/core';
import { DataSource } from '@angular/cdk/table';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { map, filter } from 'rxjs/operators';
import { merge} from 'rxjs';
import { MatTableDataSource, MatTabChangeEvent } from '@angular/material';

@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.css']
})
export class AttendanceComponent implements OnInit {

  displayedColumns: string[] = ['position', 'rollNumber', 'pic', 'name', 'actions', 'status'];

  presentDataSource = AttendanceBeanDataSource;
  ATTENDANCE_DATA: StudentBean[] = [];
  constructor() { }

  attendenceDatabase: AttendenceDatabase;
  attendenceSheet: AttendenceDatabase;
  dataSource: AttendanceBeanDataSource | null;


  ATTENDANCE_SHEET: BehaviorSubject<StudentBean[]> = new BehaviorSubject<StudentBean[]>([]);

  lateAttendanceDataSource: AttendanceBeanDataSource;
  absentAttendanceDataSource: MatTableDataSource<any>;
  presentAttendanceDataSource: MatTableDataSource<any>;

  ngOnInit() {
    this.attendenceDatabase = new AttendenceDatabase();
    this.attendenceSheet = new AttendenceDatabase();
    this.attendenceDatabase.addUser();
    this.dataSource = new AttendanceBeanDataSource(this.attendenceDatabase);
    this.lateAttendanceDataSource = new AttendanceBeanDataSource(this.attendenceSheet);
    this.absentAttendanceDataSource = new MatTableDataSource(this.attendenceSheet.data);
    this.presentAttendanceDataSource = new MatTableDataSource(this.attendenceSheet.data);

  }

  onLinkClick(event: MatTabChangeEvent) {
    // console.log('event => ', event);
    // console.log('index => ', event.index);
    // console.log('tab => ', event.tab.textLabel);
    if (event.tab.textLabel == 'Attendance Sheet') {
      this.dataSource.filter = null;
    }
    if (event.tab.textLabel == 'Late') {
      this.lateAttendanceDataSource.filter = 'late';
    }
    if (event.tab.textLabel == 'Absent') {
      this.absentAttendanceDataSource.filter = 'absent';
    }
    if (event.tab.textLabel == 'Present') {
      this.presentAttendanceDataSource.filter = 'present';
    }
  }
  markTheAttendace(student: StudentBean, staus: string) {
    student.status = staus;
    //this.attendenceDatabase.updateAttendaceStatus(student);
    this.attendenceDatabase.deleteAttendaceStatus(student);
    this.lateAttendanceDataSource.filter = 'late';
    this.dataSource.filter = '';
    this.absentAttendanceDataSource.filter = 'absent';
    this.presentAttendanceDataSource.filter = 'present';
    this.attendenceSheet.addStudent(student);
      //console.log(this.ATTENDANCE_DATA);
      //console.log(this.attendenceDatabase.data);
      console.log(this.attendenceSheet.data);
  }
}

export interface StudentBean {
  name: string;
  position: number;
  rollNumber: number;
  pic: string;
  status: string;
}

export class AttendenceDatabase {
  dataChange: BehaviorSubject<StudentBean[]> = new BehaviorSubject<StudentBean[]>([]);
  get data(): StudentBean[] { return this.dataChange.value; }
  constructor() {
    // Fill up the database with 100 users.
    //this.addUser();
    const copiedData: StudentBean[] = [];
    this.dataChange.next(copiedData);
  }
  addUser() {
    const copiedData: StudentBean[] = [
      { position: 1, name: 'Katy', rollNumber: 101, pic: '1', status: null },
      { position: 2, name: 'Helium', rollNumber: 102, pic: '2', status: null },
      { position: 3, name: 'Lithium', rollNumber: 103, pic: '3', status: null },
      { position: 4, name: 'Beryllium', rollNumber: 104, pic: '4', status: null },
      { position: 5, name: 'Boron', rollNumber: 105, pic: '5', status: null },
      { position: 6, name: 'Carbon', rollNumber: 106, pic: '11', status: null },
      { position: 7, name: 'Nitrogen', rollNumber: 107, pic: '7', status: null },
      { position: 8, name: 'Oxygen', rollNumber: 108, pic: '8', status: null },
      { position: 9, name: 'Jennifer', rollNumber: 109, pic: '9', status: null},
      { position: 10, name: 'Mona', rollNumber: 110, pic: '14', status: null },
    ];
    this.dataChange.next(copiedData);
  }

  updateAttendaceStatus(studentBean: StudentBean) {
    const copiedData = this.data.slice();
    const index = copiedData.indexOf(studentBean);
    copiedData[index] = studentBean;
    this.dataChange.next(copiedData);
  }

  addStudent(student: StudentBean) {
    const copiedData = this.data.slice();
    const index = copiedData.indexOf(student);
    if(index < 0) {
      copiedData.push(student);
    }
    this.dataChange.next(copiedData);
  }
  deleteAttendaceStatus(studentBean: StudentBean) {
    const copiedData = this.data.slice();
    const index = copiedData.indexOf(studentBean);
    copiedData.splice(index, 1);
    this.dataChange.next(copiedData);
  }
}

export class AttendanceBeanDataSource extends DataSource<any> {

  constructor(private _exampleDatabase: AttendenceDatabase) {
    super();
  }

  _filterChange = new BehaviorSubject('');
  get filter(): string { return this._filterChange.value; }
  set filter(filter: string) { this._filterChange.next(filter); }

   connect(): Observable<StudentBean[]> {
     return this._exampleDatabase.dataChange; 
   }
  
  disconnect() { }
}


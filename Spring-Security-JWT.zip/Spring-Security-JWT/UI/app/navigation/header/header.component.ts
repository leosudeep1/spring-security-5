import { Observable } from 'rxjs';
import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import * as fromRoot from './../../app.reducer';
import { Store } from '@ngrx/store';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  isLoggedIn$ : Observable<boolean>;

  @Output() sidenavToggle = new EventEmitter<void>();
  constructor(private store: Store<fromRoot.State>) { }

  ngOnInit() {
  }

  onToggleSidenav() {
    this.sidenavToggle.emit();
  }

  checkToken() {
    this.isLoggedIn$ = this.store.select(fromRoot.getIsAuthenticated);
    console.log(this.isLoggedIn$);
  }
}

package com.example.demo.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

@Embeddable
public class CommonDetails {

	@Column(name = "ADDRESS")
	private String address;

	@Column(name = "PRIMARY_NUMBER")
	@NotNull
	private long primaryNumber;

	@Column(name = "SECONDARY_NUMBER")
	private long secondaryNumber;

	@Column(name = "DATE_OF_BIRTH")
	@NotNull
	private Date dateOfBirth;

	@Column(name = "CITY")
	@NotNull
	private String city;

	@Column(name = "STATE")
	@NotNull
	private String state;

	@Column(name = "LANDMARK")
	private String landmark;

	@Column(name = "AADHAR_NUMBER")
	@NotNull
	private String aadharNumber;

	@Column(name = "PASSPORT_NUMBER")
	private String passportNumber;

	
	public CommonDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	private CommonDetails(CommonDetailsBuilder builder) {
		this.address = builder.address;
		this.primaryNumber = builder.primaryNumber;
		this.secondaryNumber = builder.secondaryNumber;
		this.dateOfBirth = builder.dateOfBirth;
		this.city = builder.city;
		this.state = builder.state;
		this.landmark = builder.landmark;
		this.aadharNumber = builder.aadharNumber;
		this.passportNumber = builder.passportNumber;
	}



	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getPrimaryNumber() {
		return primaryNumber;
	}

	public void setPrimaryNumber(long primaryNumber) {
		this.primaryNumber = primaryNumber;
	}

	public long getSecondaryNumber() {
		return secondaryNumber;
	}

	public void setSecondaryNumber(long secondaryNumber) {
		this.secondaryNumber = secondaryNumber;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}
	
	public static class CommonDetailsBuilder {
		
		private String address;
		private long primaryNumber;
		private long secondaryNumber;
		private Date dateOfBirth;
		private String city;
		private String state;
		private String landmark;
		private String aadharNumber;
		private String passportNumber;
		
		public CommonDetailsBuilder setAddress(String address) {
			this.address = address;
			return this;
		}
		public CommonDetailsBuilder setPrimaryNumber(long primaryNumber) {
			this.primaryNumber = primaryNumber;
			return this;
		}
		public CommonDetailsBuilder setSecondaryNumber(long secondaryNumber) {
			this.secondaryNumber = secondaryNumber;
			return this;
		}
		public CommonDetailsBuilder setDateOfBirth(Date dateOfBirth) {
			this.dateOfBirth = dateOfBirth;
			return this;
		}
		public CommonDetailsBuilder setCity(String city) {
			this.city = city;
			return this;
		}
		public CommonDetailsBuilder setState(String state) {
			this.state = state;
			return this;
		}
		public CommonDetailsBuilder setLandmark(String landmark) {
			this.landmark = landmark;
			return this;
		}
		public CommonDetailsBuilder setAadharNumber(String aadharNumber) {
			this.aadharNumber = aadharNumber;
			return this;
		}
		public CommonDetailsBuilder setPassportNumber(String passportNumber) {
			this.passportNumber = passportNumber;
			return this;
		}
		
		public CommonDetails build() {
			return new CommonDetails(this);
		}
	}

}

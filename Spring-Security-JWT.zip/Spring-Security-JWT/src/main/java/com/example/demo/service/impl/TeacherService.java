package com.example.demo.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.AppUser;
import com.example.demo.entity.CommonDetails;
import com.example.demo.entity.Role;
import com.example.demo.entity.Teacher;
import com.example.demo.enums.RoleName;
import com.example.demo.exception.AppException;
import com.example.demo.payload.request.CommonSignupRequestPayload;
import com.example.demo.payload.request.SignupRequestPayload;
import com.example.demo.payload.request.TeacherSignupRequestPayload;
import com.example.demo.payload.response.ApiResponse;
import com.example.demo.repository.RoleRepository;
import com.example.demo.repository.TeacherRepository;
import com.example.demo.service.ITeacherService;

@Service
public class TeacherService implements ITeacherService {

	@Autowired
	private TeacherRepository teacherRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private PasswordEncoder encoder;
	
	@Override
	@Transactional
	public Optional<?> saveTeacher(TeacherSignupRequestPayload payload) throws AppException {
		
		SignupRequestPayload signupPayload = payload.getSignupPayload();
		CommonSignupRequestPayload commonDetailsPayload = payload.getCommonDetailsPayload();
		Date dob = convertToDate(commonDetailsPayload.getDateOfBirth());
		
		if(teacherRepository.existsByCredentialsUsername(signupPayload.getUsername())) {
            return Optional.of(new ApiResponse(false, "Username is already in use!"));
        }

        if(teacherRepository.existsByCredentialsEmail(signupPayload.getEmail())) {
        	return Optional.of(new ApiResponse(false, "Email is already in use!"));
        }
        
		Role role = roleRepository.findByName(RoleName.ROLE_TEACHER)
				.orElseThrow(() -> new AppException("Teacher Role not set."));
		
		AppUser appUser = new AppUser(
					signupPayload.getName(), 
					signupPayload.getUsername(), 
					signupPayload.getEmail(),
					encoder.encode(signupPayload.getPassword()));
		appUser.setRoles(Collections.singleton(role));
		
		CommonDetails commonDetails = new CommonDetails
				.CommonDetailsBuilder()
				.setAadharNumber(commonDetailsPayload.getAadharNumber())
				.setAddress(commonDetailsPayload.getAddress())
				.setCity(commonDetailsPayload.getCity())
				.setDateOfBirth(dob)
				.setLandmark(commonDetailsPayload.getLandmark())
				.setPassportNumber(commonDetailsPayload.getPassportNumber())
				.setPrimaryNumber(convertToLong(commonDetailsPayload.getPrimaryNumber()))
				.setSecondaryNumber(convertToLong(commonDetailsPayload.getSecondaryNumber()))
				.setState(commonDetailsPayload.getState())
				.build();
		
		Teacher teacher = new Teacher();
		teacher.setCommanDetails(commonDetails);
		teacher.setCredentials(appUser);
		Teacher afterSave = teacherRepository.save(teacher);
		return Optional.of(afterSave);
	}

	@Override
	public Teacher getTeacherDetailsByUsername(String username) {
		// TODO Auto-generated method stub
		return null;
	}
	
	private long convertToLong(String value) {
		try {
			return Long.parseLong(value);
		} catch (NumberFormatException e) {
			throw new AppException("Not a valid Phone Number");
		}
	}
	
	private Date convertToDate(String date) {
		try {
			return new SimpleDateFormat("dd/MM/yyyy").parse(date);
		} catch (ParseException e) {
			throw new AppException("Not a Valid Date");
		}
	}

}

package com.example.demo.controller;

import static org.hamcrest.CoreMatchers.instanceOf;

import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Teacher;
import com.example.demo.payload.request.TeacherSignupRequestPayload;
import com.example.demo.payload.response.ApiResponse;
import com.example.demo.service.ITeacherService;

@RestController
public class TeacherController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(TeacherController.class);
	@Autowired
	private ITeacherService teacherService;
	
	//@PreAuthorize("hashRole('ROLE_ADMIN')")
	@PostMapping("/registerTeacher")
    public ResponseEntity<?> registerUser(@Valid @RequestBody TeacherSignupRequestPayload signUpRequest) {
		
		LOGGER.info(signUpRequest.toString());
		Optional<?> opt = teacherService.saveTeacher(signUpRequest);
		
		if(opt.get() instanceof ApiResponse) {
			return ResponseEntity.badRequest().body(opt.get());
		}
		//if(opt.get(). instanceOf(ApiResponse.class))ResponseEntity.badRequest().body(t));
		
		Teacher teacher = (Teacher) opt.get();
		return ResponseEntity.ok().body("Teacher Created with id :"+teacher.getId());
	}
}

package com.example.demo.service;

import java.util.Optional;

import com.example.demo.entity.Teacher;
import com.example.demo.exception.AppException;
import com.example.demo.payload.request.TeacherSignupRequestPayload;

public interface ITeacherService {

	public Optional<?> saveTeacher(TeacherSignupRequestPayload payload) throws AppException;
	public Teacher getTeacherDetailsByUsername(String username);
}
